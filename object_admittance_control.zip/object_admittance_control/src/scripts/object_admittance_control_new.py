import mujoco
import numpy as np
from mujoco.viewer import launch
import time

# Import the controller class
from utils.mujoco_velocity_controller.samriddhi_dual_arm_velocity_controller import VelocityControllerGC

def get_contact_wrenches(model, data):
    """
    Get wrenches (force/torque) at contact points between end-effectors and box.
    Prints the wrench values when contact is detected.
    """
    # Find box body ID
    box_body_id = -1
    for i in range(model.nbody):
        if "box" in model.body(i).name:
            box_body_id = i
            break
    
    if box_body_id == -1:
        return np.zeros(6), np.zeros(6), False
    
    # Get all geom IDs for the box
    box_geom_ids = []
    for i in range(model.ngeom):
        if model.geom_bodyid[i] == box_body_id:
            box_geom_ids.append(i)
    
    # Initialize wrenches
    left_wrench = np.zeros(6)
    right_wrench = np.zeros(6)
    
    # Check all contacts
    contact_detected = False
    for i in range(data.ncon):
        contact = data.contact[i]
        
        # Check if this contact involves the box
        if contact.geom1 in box_geom_ids or contact.geom2 in box_geom_ids:
            # Get contact force
            contact_force = np.zeros(6)
            mujoco.mj_contactForce(model, data, i, contact_force)
            
            # Determine which end effector is involved
            other_geom = contact.geom2 if contact.geom1 in box_geom_ids else contact.geom1
            other_body = model.geom_bodyid[other_geom]
            body_name = model.body(other_body).name
            
            # Compute torque around box center
            contact_pos = contact.pos.copy()
            box_pos = data.xpos[box_body_id].copy()
            lever_arm = contact_pos - box_pos
            torque = np.cross(lever_arm, contact_force[:3])
            
            # Add to appropriate wrench
            if "left" in body_name.lower():
                left_wrench[:3] += contact_force[:3]
                left_wrench[3:] += torque
                contact_detected = True
            elif "right" in body_name.lower():
                right_wrench[:3] += contact_force[:3]
                right_wrench[3:] += torque
                contact_detected = True
    
    # Print wrenches if contact is detected
    if contact_detected:
        print("\n--- CONTACT WRENCHES ---")
        print(f"Left end-effector wrench:")
        print(f"  Force: [{left_wrench[0]:.4f}, {left_wrench[1]:.4f}, {left_wrench[2]:.4f}]N")
        print(f"  Torque: [{left_wrench[3]:.4f}, {left_wrench[4]:.4f}, {left_wrench[5]:.4f}]Nm")
        print(f"  Force magnitude: {np.linalg.norm(left_wrench[:3]):.4f}N")
        
        print(f"\nRight end-effector wrench:")
        print(f"  Force: [{right_wrench[0]:.4f}, {right_wrench[1]:.4f}, {right_wrench[2]:.4f}]N")
        print(f"  Torque: [{right_wrench[3]:.4f}, {right_wrench[4]:.4f}, {right_wrench[5]:.4f}]Nm")
        print(f"  Force magnitude: {np.linalg.norm(right_wrench[:3]):.4f}N")
        
        # Calculate combined wrench
        combined_wrench = left_wrench + right_wrench
        print(f"\nCombined wrench:")
        print(f"  Force: [{combined_wrench[0]:.4f}, {combined_wrench[1]:.4f}, {combined_wrench[2]:.4f}]N")
        print(f"  Torque: [{combined_wrench[3]:.4f}, {combined_wrench[4]:.4f}, {combined_wrench[5]:.4f}]Nm")
        print(f"  Force magnitude: {np.linalg.norm(combined_wrench[:3]):.4f}N")
        
        # Get object mass and compute weight
        object_mass = model.body_mass[box_body_id]
        weight_force = object_mass * 9.81  # N
        print(f"\nObject mass: {object_mass:.3f}kg, Weight: {weight_force:.3f}N")
        
        # Check if lifting force exceeds weight
        if combined_wrench[2] > weight_force:
            print("✅ Lifting force exceeds object weight")
        else:
            print("⚠️ Lifting force insufficient to overcome weight")
    
    return left_wrench, right_wrench, contact_detected

def get_ft_sensor_readings(model, data):
    """Get force-torque sensor readings from the model."""
    sensor_readings = {}
    
    # Iterate through all sensors
    for i in range(model.nsensor):
        sensor_name = model.sensor(i).name
        sensor_type = model.sensor(i).type
        
        # Check if it's a force or torque sensor
        if sensor_type == mujoco.mjtSensor.mjSENS_FORCE or sensor_type == mujoco.mjtSensor.mjSENS_TORQUE:
            # Get the sensor data
            adr = int(model.sensor(i).adr)  # Convert to int to avoid indexing error
            dim = int(model.sensor(i).dim)  # Convert to int to avoid indexing error
            sensor_readings[sensor_name] = data.sensordata[adr:adr+dim].copy()
    
    # Print sensor readings
    if sensor_readings:
        print("\n--- FT SENSOR READINGS ---")
        for name, values in sensor_readings.items():
            print(f"{name}: {values}")
    
    return sensor_readings

def compute_object_admittance_control(model, data, left_wrench, right_wrench, desired_height=0.5):
    """
    Compute object admittance control using the equation:
    ẋₒ* = ẋₒ + D⁻¹[W - W* - K(xₒ* - xₒ)]
    
    Args:
        model: MuJoCo model
        data: MuJoCo data
        left_wrench: Wrench (force/torque) from left end-effector (6×1 vector)
        right_wrench: Wrench (force/torque) from right end-effector (6×1 vector)
        desired_height: Desired height for the object (in meters)
        
    Returns:
        object_velocity: Computed desired object velocity (6×1 vector)
    """
    # Find box body ID
    box_body_id = -1
    for i in range(model.nbody):
        if "box" in model.body(i).name:
            box_body_id = i
            break
    
    if box_body_id == -1:
        print("⚠️ Could not find box body")
        return np.zeros(6)
    
    # 1. Get current object pose
    current_obj_pos = data.xpos[box_body_id].copy()
    current_obj_quat = data.xquat[box_body_id].copy()
    
    # 2. Define desired object pose (same position but higher z)
    desired_obj_pos = current_obj_pos.copy()
    desired_obj_pos[2] = desired_height  # Set desired height
    desired_obj_quat = current_obj_quat.copy()  # Keep same orientation
    
    # 3. Compute position error
    pos_error = desired_obj_pos - current_obj_pos
    
    # Calculate distance to target height
    height_error = desired_height - current_obj_pos[2]
    height_error_percentage = min(100, max(0, (height_error / (desired_height - 0.1)) * 100))
    
    # Check if we're very close to the target height
    height_threshold = 0.01  # 1cm threshold
    if height_error < height_threshold:
        print(f"⚠️ Very close to target height! Error: {height_error:.4f}m")
        # Return minimal velocity to gently approach target
        return np.array([0, 0, 0.02, 0, 0, 0])
    
    # 4. Get current object velocity (spatial velocity in world frame)
    current_obj_vel = np.zeros(6)
    if hasattr(data, 'cvel'):
        # Linear velocity is in the first 3 elements, angular in the last 3
        current_obj_vel[:3] = data.cvel[box_body_id, :3]
        current_obj_vel[3:] = data.cvel[box_body_id, 3:6]
    else:
        # If cvel not available, estimate from qvel
        # This is a simplified approximation
        current_obj_vel = np.zeros(6)
    
    # 5. Combine wrenches from both end-effectors
    W = left_wrench + right_wrench
    
    # 6. Define desired wrench (W*)
    # For lifting, we want to counteract gravity plus add upward force
    object_mass = model.body_mass[box_body_id]
    W_desired = np.zeros(6)
    
    # Calculate weight force
    weight_force = object_mass * 9.81  # N
    
    # Scale the upward force based on remaining distance to target
    # More force when far from target, less as we approach
    # Significantly increase the upward force factor to overcome weight
    upward_force_factor = 20.0 + 15.0 * (height_error_percentage / 100)
    
    # Set desired wrench to counteract gravity plus additional upward force
    # Multiply weight by a safety factor to ensure sufficient lifting force
    W_desired[2] = weight_force * 2.0 + upward_force_factor  # 2x gravity + additional force
    
    # Print weight and desired lifting force for debugging
    print(f"Object mass: {object_mass:.3f}kg, Weight: {weight_force:.3f}N")
    print(f"Desired lifting force: {W_desired[2]:.3f}N (safety factor: {W_desired[2]/weight_force:.1f}x weight)")
    
    # 7. Define stiffness (K) and damping (D) matrices
    # These are diagonal matrices for simplicity
    # Increase stiffness for more aggressive position control
    K = np.diag([200.0, 200.0, 400.0, 20.0, 20.0, 20.0])  # Stiffness (increased for z-axis)
    D = np.diag([20.0, 20.0, 10.0, 3.0, 3.0, 3.0])        # Damping (decreased for faster response)
    
    # 8. Compute pose error vector (6×1)
    pose_error = np.zeros(6)
    pose_error[:3] = pos_error
    
    
    # 9. Compute the admittance control law
    # ẋₒ* = ẋₒ + D⁻¹[W - W* - K(xₒ* - xₒ)]
    D_inv = np.linalg.inv(D)
    stiffness_term = K @ pose_error
    wrench_term = W - W_desired
    
    # Print actual vs desired wrench
    print(f"Actual wrench (z): {W[2]:.3f}N, Desired wrench (z): {W_desired[2]:.3f}N")
    print(f"Wrench difference (z): {wrench_term[2]:.3f}N")
    
    # Complete admittance control law
    object_velocity = current_obj_vel + D_inv @ (wrench_term - stiffness_term)
    
    # 10. Apply velocity limits for safety
    max_lin_vel = 0.5  # m/s (increased for faster movement)
    max_ang_vel = 0.5  # rad/s
    object_velocity[:3] = np.clip(object_velocity[:3], -max_lin_vel, max_lin_vel)
    object_velocity[3:] = np.clip(object_velocity[3:], -max_ang_vel, max_ang_vel)
    
    # For lifting, ensure we have a minimum upward velocity if not at desired height
    if height_error > 0.01:  # If we need to move up
        # Scale minimum velocity based on distance to target
        min_upward_vel = 0.2 * (height_error_percentage / 100 + 0.5)  # At least 10-20 cm/s upward
        object_velocity[2] = max(object_velocity[2], min_upward_vel)
    else:
        # Near target, slow down to avoid overshooting
        object_velocity[2] = min(object_velocity[2], 0.05)
    
    # Print debug information
    print(f"Height error: {height_error:.4f} m ({height_error_percentage:.1f}%)")
    print(f"Desired object velocity: {object_velocity}")
    
    return object_velocity

def object_velocity_to_joint_velocities(model, data, object_velocity):
    """
    Convert object velocity to joint velocities for dual-arm manipulation.
    
    Args:
        model: MuJoCo model
        data: MuJoCo data
        object_velocity: Desired object velocity (6×1 vector)
        
    Returns:
        joint_velocities: Joint velocities for both arms
    """
    try:
        # Find box body ID
        box_body_id = -1
        for i in range(model.nbody):
            if "box" in model.body(i).name:
                box_body_id = i
                break
        
        if box_body_id == -1:
            print("⚠️ Could not find box body")
            return np.zeros(12)  # Assuming 6 DOFs per arm
        
        # Find end-effector site IDs - search more broadly for site names
        left_ee_site_id = -1
        right_ee_site_id = -1
        
        # Print all available sites for debugging
        print("\n--- AVAILABLE SITES ---")
        for i in range(model.nsite):
            site_name = model.site(i).name
            print(f"Site {i}: {site_name}")
            
            # Look for end-effector sites
            if "left" in site_name.lower() and ("ee" in site_name.lower() or "end" in site_name.lower() or "gripper" in site_name.lower()):
                left_ee_site_id = i
            elif "right" in site_name.lower() and ("ee" in site_name.lower() or "end" in site_name.lower() or "gripper" in site_name.lower()):
                right_ee_site_id = i
        
        # If specific end-effector sites not found, use any left/right sites
        if left_ee_site_id == -1 or right_ee_site_id == -1:
            print("⚠️ Could not find specific end-effector sites, searching for any left/right sites...")
            for i in range(model.nsite):
                site_name = model.site(i).name
                if "left" in site_name.lower() and left_ee_site_id == -1:
                    left_ee_site_id = i
                    print(f"Using as left end-effector: {site_name}")
                elif "right" in site_name.lower() and right_ee_site_id == -1:
                    right_ee_site_id = i
                    print(f"Using as right end-effector: {site_name}")
        
        if left_ee_site_id == -1 or right_ee_site_id == -1:
            print("⚠️ Could not find end-effector sites")
            return np.zeros(12)  # Assuming 6 DOFs per arm
        
        # Find joint IDs for each arm
        left_arm_dofs = []
        right_arm_dofs = []
        
        # Assuming the first half of actuators belong to the left arm and the second half to the right arm
        num_actuators = model.nu
        actuators_per_robot = num_actuators // 2
        
        # Get DOFs for left arm
        for i in range(actuators_per_robot):
            joint_id = model.actuator_trnid[i, 0]
            dof_adr = model.jnt_dofadr[joint_id]
            left_arm_dofs.append(dof_adr)
        
        # Get DOFs for right arm
        for i in range(actuators_per_robot, num_actuators):
            joint_id = model.actuator_trnid[i, 0]
            dof_adr = model.jnt_dofadr[joint_id]
            right_arm_dofs.append(dof_adr)
        
        # Get Jacobians for both end-effectors
        jac_left = np.zeros((6, model.nv))
        jac_right = np.zeros((6, model.nv))
        
        mujoco.mj_jacSite(model, data, jac_left[:3], jac_left[3:], left_ee_site_id)
        mujoco.mj_jacSite(model, data, jac_right[:3], jac_right[3:], right_ee_site_id)
        
        # Number of DOFs per arm
        n_dofs_per_arm = len(left_arm_dofs)
        total_dofs = n_dofs_per_arm * 2
        
        # Extract relevant columns from Jacobians
        jac_left_arm = jac_left[:, left_arm_dofs]
        jac_right_arm = jac_right[:, right_arm_dofs]
        
        # Combine Jacobians for both arms
        J_combined = np.zeros((12, total_dofs))
        J_combined[:6, :n_dofs_per_arm] = jac_left_arm
        J_combined[6:, n_dofs_per_arm:] = jac_right_arm
        
        # For lifting, we're mainly concerned with the z-direction
        # Extract z-rows from Jacobians
        J_z = np.zeros((2, total_dofs))
        J_z[0, :n_dofs_per_arm] = jac_left_arm[2, :]  # z-row for left arm
        J_z[1, n_dofs_per_arm:] = jac_right_arm[2, :]  # z-row for right arm
        
        # Compute pseudoinverse
        J_z_pinv = np.linalg.pinv(J_z)
        
        # Compute joint velocities for lifting
        v_z = np.array([object_velocity[2], object_velocity[2]])  # Same z-velocity for both contacts
        joint_velocities = J_z_pinv @ v_z
        
        # Scale for faster movement
        joint_velocities *= 2.0
        
        # Apply joint velocity limits
        max_joint_vel = 0.5  # rad/s
        joint_velocities = np.clip(joint_velocities, -max_joint_vel, max_joint_vel)
        
        print(f"Object velocity: {object_velocity}")
        print(f"Joint velocities: {joint_velocities}")
        
        return joint_velocities
        
    except Exception as e:
        print(f"Error in object_velocity_to_joint_velocities: {e}")
        import traceback
        traceback.print_exc()
        
        # # Return a simple velocity command as fallback
        # return np.array([
        #     # Left arm - adjust shoulder_lift and elbow joints for lifting
        #     0.0, 0.2, 0.0, 0.2, 0.0, 0.0,
        #     # Right arm - adjust shoulder_lift and elbow joints for lifting
        #     0.0, 0.2, 0.0, 0.2, 0.0, 0.0
        # ])

def main():
    # Path to your XML file
    xml_file_path = "/home/samriddhi/RL-Based-Dual-Arm-Manipulation/Dual_Arm_Manipulation/robot_descriptions/dual_arm_heal_effort_actuation_rs.xml"
    
    # Check if file exists
    import os
    if not os.path.exists(xml_file_path):
        print(f"Error: XML file not found at {xml_file_path}")
        return
    
    print(f"Found XML file at {xml_file_path}")
    
    # Try to load the model
    try:
        model = mujoco.MjModel.from_xml_path(xml_file_path)
        print("Successfully loaded MuJoCo model")
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    # Load the model and data
    data = mujoco.MjData(model)

    # Reset the simulation to ensure clean initial state
    mujoco.mj_resetData(model, data)
    mujoco.mj_forward(model, data)

    # Define the target height for lifting the box (in meters)
    # This is the absolute height from the ground
    target_lift_height = 0.5  # 50 cm from ground
    
    # Find box body ID to get initial height
    box_body_id = -1
    for i in range(model.nbody):
        if "box" in model.body(i).name:
            box_body_id = i
            break
    
    if box_body_id != -1:
        initial_box_height = data.xpos[box_body_id][2]
        print(f"Initial box height: {initial_box_height:.4f} m")
        print(f"Target lift height: {target_lift_height:.4f} m")
        print(f"Lift distance: {target_lift_height - initial_box_height:.4f} m")
    else:
        print("Warning: Could not find box body to determine initial height")
        initial_box_height = 0.1  # Default assumption
    
    # Define per-joint gains for the velocity controller
    # Format: [joint1, joint2, joint3, joint4, joint5, joint6] for each robot
    kd_gains = np.array([
        # Left robot - increased gains for better tracking
        60.0, 100.0, 70.0, 30.0, 15.0, 15.0,
        # Right robot - increased gains for better tracking
        60.0, 100.0, 70.0, 30.0, 15.0, 15.0
    ])
    
    ki_gains = np.array([
        # Left robot - increased integral gains
        0.01, 0.1, 0.01, 0.005, 0.002, 0.002,
        # Right robot - increased integral gains
        0.01, 0.1, 0.01, 0.005, 0.002, 0.002
    ])
    
    # Create the velocity controller with per-joint gains
    controller = VelocityControllerGC(model, data, kd=kd_gains, ki=ki_gains)
    
    # Get number of actuators per robot
    num_actuators = controller.num_actuators
    actuators_per_robot = num_actuators // 2
    
    print(f"Total actuators: {num_actuators}, Actuators per robot: {actuators_per_robot}")
    
    # Define target joint positions for both robots
    # First target positions (approach positions)
    first_target_positions = np.zeros(num_actuators)
    
    # Left robot (first half of actuators)
    first_target_positions[:actuators_per_robot] = [-0.0805, 1.07, -0.126, 1.53, -0.00978, 0]
    
    # Right robot (second half of actuators)
    first_target_positions[actuators_per_robot:] = [0.105, 1.07, -0.126, -1.45, -0.00901, 0]
    
    # Second target positions (grasp positions)
    second_target_positions = np.zeros(num_actuators)
    
    # Left robot (first half of actuators)
    second_target_positions[:actuators_per_robot] = [0.251, 1.16, -0.0314, 1.79, -0.00978, 0]
    
    # Right robot (second half of actuators)
    second_target_positions[actuators_per_robot:] = [-0.251, 1.16, -0.0314, -1.79, -0.0314, 0]
    
    # Initialize control state
    control_state = {
        "phase": "reaching_first_target",
        "current_targets": first_target_positions.copy(),
        "phase_start_time": time.time(),
        "last_phase_change": time.time(),
        "last_print_time": time.time(),
        "initial_box_height": initial_box_height,
        "target_lift_height": target_lift_height,
        "lifting_complete": False
    }
    
    # Print target positions
    print("\nFirst target positions (approach):")
    for i in range(num_actuators):
        robot = "Left" if i < actuators_per_robot else "Right"
        joint_in_robot = i % actuators_per_robot
        print(f"{robot} Robot - Joint {joint_in_robot}: {first_target_positions[i]:.4f}")
    
    print("\nSecond target positions (grasp):")
    for i in range(num_actuators):
        robot = "Left" if i < actuators_per_robot else "Right"
        joint_in_robot = i % actuators_per_robot
        print(f"{robot} Robot - Joint {joint_in_robot}: {second_target_positions[i]:.4f}")
    
    # Define per-joint position control gains (kp)
    kp_gains = np.array([
        # Left robot - increased gains
        15.0, 60.0, 15.0, 5.0, 3.0, 3.0,
        # Right robot - increased gains
        15.0, 60.0, 15.0, 5.0, 3.0, 3.0
    ])
    
    # Maximum allowed velocity for each joint (rad/s)
    max_velocities = np.array([
        # Left robot - increased for faster movement
        0.8, 0.8, 0.8, 1.0, 1.0, 1.0,
        # Right robot - increased for faster movement
        0.8, 0.8, 0.8, 1.0, 1.0, 1.0
    ])
    
    # Position error threshold for considering a joint "reached" (radians)
    position_thresholds = np.array([
        # Left robot
        0.02, 0.02, 0.02, 0.03, 0.03, 0.03,
        # Right robot
        0.02, 0.02, 0.02, 0.03, 0.03, 0.03
    ])
    
    # Function to compute velocity commands based on position error
    def position_to_velocity_trajectory(t):
        """
        Compute velocity commands based on current state and time.
        
        Args:
            t: Current simulation time
        
        Returns:
            velocity_commands: Joint velocity commands for all actuators
        """
        # Get current joint positions
        joint_positions = np.zeros(num_actuators)
        for i in range(num_actuators):
            joint_id = model.actuator_trnid[i, 0]
            joint_positions[i] = data.qpos[model.jnt_qposadr[joint_id]]
        
        # Control logic based on current phase
        current_time = time.time()
        
        # Print current phase periodically
        if current_time - control_state.get("last_print_time", 0) > 2.0:
            print(f"\nCurrent control phase: {control_state['phase']}")
            control_state["last_print_time"] = current_time
        
        # Store the active control strategy for logging
        if "active_control_strategy" not in control_state:
            control_state["active_control_strategy"] = "position_control"
        
        if control_state["phase"] == "reaching_first_target" or control_state["phase"] == "reaching_second_target":
            control_state["active_control_strategy"] = "position_control"
            # Compute position errors based on current targets
            position_errors = control_state["current_targets"] - joint_positions
            
            # Compute velocity commands using proportional control with per-joint gains
            velocity_commands = kp_gains * position_errors
            
            # Limit velocity commands using per-joint max velocities
            velocity_commands = np.clip(velocity_commands, -max_velocities, max_velocities)
            
            # Apply a small deadband to prevent tiny movements
            for i in range(num_actuators):
                if abs(position_errors[i]) < position_thresholds[i] * 0.5:
                    velocity_commands[i] = 0.0
            
            # Check if all joints have reached their targets
            all_reached = True
            for i in range(num_actuators):
                if abs(position_errors[i]) > position_thresholds[i]:
                    all_reached = False
                    break
            
            # If all joints have reached their targets
            if all_reached:
                if control_state["phase"] == "reaching_first_target":
                    # Switch to second target positions after reaching first targets
                    control_state["phase"] = "reaching_second_target"
                    control_state["current_targets"] = second_target_positions.copy()
                    control_state["phase_start_time"] = current_time
                    control_state["last_phase_change"] = current_time
                    print("\n🎯 Switching to second targets (grasp positions)...")
                    return np.zeros(num_actuators)  # Momentarily stop before moving to next target
                elif control_state["phase"] == "reaching_second_target":
                    # After reaching second targets, switch to sensor reading phase
                    if current_time - control_state["last_phase_change"] > 2.0:
                        control_state["phase"] = "reading_sensors"
                        control_state["last_phase_change"] = current_time
                        print("\n✅ All targets reached. Switching to sensor reading phase.")
                        return np.zeros(num_actuators)  # Maintain position
        
            return velocity_commands
        
        elif control_state["phase"] == "reading_sensors":
            control_state["active_control_strategy"] = "none"
            # After a few seconds in reading_sensors phase, switch to lifting phase
            if current_time - control_state["last_phase_change"] > 3.0:
                control_state["phase"] = "lifting_object"
                control_state["last_phase_change"] = current_time
                print("\n🔼 Starting object lifting phase...")
                print(f"Target lift height: {control_state['target_lift_height']:.4f} m")
            
            return np.zeros(num_actuators)  # Maintain position while reading sensors
        
        elif control_state["phase"] == "lifting_object":
            # Find box body ID
            box_body_id = -1
            for i in range(model.nbody):
                if "box" in model.body(i).name:
                    box_body_id = i
                    break
            
            if box_body_id == -1:
                print("⚠️ Could not find box body")
                control_state["active_control_strategy"] = "none"
                return np.zeros(num_actuators)
            
            # Get current box height
            current_box_height = data.xpos[box_body_id][2]
            
            # Check if we've reached the target height
            height_threshold = 0.01  # 1cm threshold
            if current_box_height >= control_state["target_lift_height"] - height_threshold:
                if not control_state.get("lifting_complete", False):
                    print(f"\n✅ TARGET HEIGHT REACHED! Current height: {current_box_height:.4f} m")
                    print(f"Target height was: {control_state['target_lift_height']:.4f} m")
                    print("Stopping all robot movements and maintaining position...")
                    control_state["lifting_complete"] = True
                    control_state["phase"] = "maintaining_position"
                    control_state["last_phase_change"] = current_time
                    control_state["active_control_strategy"] = "none"
                
                # Return zero velocities to stop all movements
                return np.zeros(num_actuators)
            
            # Get contact wrenches
            left_wrench, right_wrench, contact_detected = get_contact_wrenches(model, data)
            
            # Initialize contact retry counter if it doesn't exist
            if "contact_retry_count" not in control_state:
                control_state["contact_retry_count"] = 0
            
            if contact_detected:
                # Reset contact retry counter
                control_state["contact_retry_count"] = 0
                
                # Compute desired object velocity using admittance control
                object_velocity = compute_object_admittance_control(
                    model, data, left_wrench, right_wrench, 
                    desired_height=control_state["target_lift_height"]
                )
                
                # Convert object velocity to joint velocities
                joint_velocities = object_velocity_to_joint_velocities(model, data, object_velocity)
                
                # Print lifting progress
                lift_progress = (current_box_height - control_state["initial_box_height"]) / (
                    control_state["target_lift_height"] - control_state["initial_box_height"]
                ) * 100
                lift_progress = min(100, max(0, lift_progress))
                
                # Update active control strategy
                control_state["active_control_strategy"] = "admittance_control"
                print(f"🔄 ACTIVE CONTROL: ADMITTANCE CONTROL")
                print(f"Lifting progress: {lift_progress:.1f}% (Height: {current_box_height:.4f} m)")
                
                # Ensure the controller applies these velocities directly
                return joint_velocities
            else:
                # Increment contact retry counter
                control_state["contact_retry_count"] += 1
                print(f"⚠️ No contact detected. Retry count: {control_state['contact_retry_count']}")
                
                # If we've tried too many times without contact, use direct joint control
                if control_state["contact_retry_count"] > 10:
                    print("⚠️ Multiple contact failures. Using direct joint control for lifting.")
                    
                    # Direct joint control approach
                    # Initialize joint velocities
                    direct_velocities = np.zeros(num_actuators)
                    
                    # Set strong upward velocities for key joints
                    # Left arm
                    direct_velocities[1] = 0.3  # Shoulder lift (positive for upward)
                    direct_velocities[3] = 0.3  # Elbow (positive for upward)
                    
                    # Right arm
                    direct_velocities[actuators_per_robot + 1] = 0.3  # Shoulder lift (positive for upward)
                    direct_velocities[actuators_per_robot + 3] = 0.3  # Elbow (positive for upward)
                    
                    # Try to improve grasp by slightly closing the grippers
                    # Adjust these indices if your gripper joints are different
                    if actuators_per_robot >= 6:
                        direct_velocities[5] = 0.1  # Left gripper close
                        direct_velocities[actuators_per_robot + 5] = 0.1  # Right gripper close
                    
                    # Update active control strategy
                    control_state["active_control_strategy"] = "direct_joint_control"
                    print(f"🔄 ACTIVE CONTROL: DIRECT JOINT CONTROL")
                    print(f"Using direct joint velocities: {direct_velocities}")
                    
                    return direct_velocities
                else:
                    # Try to improve grasp by adjusting the grasp positions slightly
                    if control_state["contact_retry_count"] == 5:
                        print("⚠️ Adjusting grasp positions to improve contact...")
                        
                        # Create adjusted grasp positions (move slightly inward)
                        adjusted_positions = second_target_positions.copy()
                        
                        # Adjust left arm position (move right)
                        adjusted_positions[0] += 0.01  # Move right
                        
                        # Adjust right arm position (move left)
                        adjusted_positions[actuators_per_robot] -= 0.01  # Move left
                        
                        # Update targets
                        control_state["current_targets"] = adjusted_positions
                        
                        # Compute position errors
                        position_errors = control_state["current_targets"] - joint_positions
                        
                        # Compute velocity commands using proportional control
                        velocity_commands = kp_gains * position_errors
                        
                        # Limit velocity commands
                        velocity_commands = np.clip(velocity_commands, -max_velocities, max_velocities)
                        
                        # Update active control strategy
                        control_state["active_control_strategy"] = "grasp_adjustment"
                        print(f"🔄 ACTIVE CONTROL: GRASP ADJUSTMENT")
                        
                        return velocity_commands
                    
                    # Otherwise, maintain position and wait for contact
                    control_state["active_control_strategy"] = "waiting_for_contact"
                    print(f"🔄 ACTIVE CONTROL: WAITING FOR CONTACT")
                    return np.zeros(num_actuators)
        
        elif control_state["phase"] == "maintaining_position":
            control_state["active_control_strategy"] = "position_maintenance"
            # We've reached the target height and are now maintaining position
            if current_time - control_state.get("last_print_time", 0) > 5.0:
                # Find box body ID
                box_body_id = -1
                for i in range(model.nbody):
                    if "box" in model.body(i).name:
                        box_body_id = i
                        break
                
                if box_body_id != -1:
                    current_box_height = data.xpos[box_body_id][2]
                    print(f"\n✅ MAINTAINING TARGET HEIGHT: {current_box_height:.4f} m")
                    print(f"Target height was: {control_state['target_lift_height']:.4f} m")
                
                control_state["last_print_time"] = current_time
            
            # Return zero velocities to maintain position
            return np.zeros(num_actuators)
        
        else:
            # Unknown phase
            control_state["active_control_strategy"] = "unknown"
            print(f"Unknown control phase: {control_state['phase']}")
            return np.zeros(num_actuators)
    
    # Set the velocity trajectory function
    controller.set_velocity_trajectory(position_to_velocity_trajectory)
    
    # Register callback & launch viewer
    mujoco.set_mjcb_control(controller.control_callback)
    
    viewer = None
    use_viewer = False
    
    # Continuous simulation loop
    start_time = time.time()
    last_print_time = start_time
    running = True
    
    try:
        # Try to launch the viewer in a way that can be safely interrupted
        try:
            viewer = launch(model, data)
            if viewer is not None:
                use_viewer = True
                print("Viewer launched successfully")
            else:
                print("Warning: Viewer is None")
                use_viewer = False
        except KeyboardInterrupt:
            print("\nViewer launch interrupted by user.")
            running = False
        except Exception as e:
            print(f"Warning: Could not launch viewer: {e}")
            print("Continuing without visualization...")
            use_viewer = False
        
        # Main simulation loop
        while running:
            # Step the simulation
            mujoco.mj_step(model, data)
            
            # Update the viewer if available
            if use_viewer and viewer.is_running():
                viewer.sync()
            else:
                if use_viewer:
                    running = False
                    print("Viewer closed. Stopping simulation.")
            
            # Check for contact wrenches if we've reached the second target
            if control_state["phase"] == "reaching_second_target" or control_state["phase"] == "reading_sensors":
                left_wrench, right_wrench, contact_detected = get_contact_wrenches(model, data)
                
                # Read FT sensors in the reading_sensors phase
                if control_state["phase"] == "reading_sensors":
                    get_ft_sensor_readings(model, data)
            
            # Periodically print joint positions and errors
            current_time = time.time()
            if current_time - last_print_time > 1.0:  # Every second
                last_print_time = current_time
                
                # Print current phase
                print(f"\nCurrent phase: {control_state['phase']}")
                
                # Calculate position errors
                position_errors = np.zeros(num_actuators)
                for i in range(num_actuators):
                    joint_id = model.actuator_trnid[i, 0]
                    current_pos = data.qpos[model.jnt_qposadr[joint_id]]
                    position_errors[i] = control_state["current_targets"][i] - current_pos
                
                # Print position errors for a few joints (to avoid cluttering the output)
                print("Position errors (sample):")
                for i in range(0, num_actuators, 2):  # Print every other joint
                    robot = "Left" if i < actuators_per_robot else "Right"
                    joint_in_robot = i % actuators_per_robot
                    print(f"{robot} Robot - Joint {joint_in_robot}: Error={position_errors[i]:.4f}")
                
                # In lifting phase, print object height
                if control_state["phase"] == "lifting_object":
                    # Find box body ID
                    box_body_id = -1
                    for i in range(model.nbody):
                        if "box" in model.body(i).name:
                            box_body_id = i
                            break
                    
                    if box_body_id != -1:
                        box_height = data.xpos[box_body_id][2]
                        print(f"Box height: {box_height:.4f} m")
            
            # Small sleep to prevent CPU overload
            time.sleep(0.001)
    
    except KeyboardInterrupt:
        print("\nSimulation interrupted by user.")
    except Exception as e:
        print(f"Error in simulation loop: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean up resources
        print("Cleaning up resources...")
        mujoco.set_mjcb_control(None)
        if use_viewer and viewer is not None:
            viewer.close()

if __name__ == "__main__":
    main()
